% Matlab code generates the contour graph Figure 5. 
% Inputs  LFepi7F, LFepi8F and LFepi9F generated from
% ReEndSup1Re.prg.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

hst7 = load('LFepi7F.mat');
DynG7 = double(hst7.st_dataset);
hst8 = load('LFepi8F.mat');
DynG8 = double(hst8.st_dataset);
hst9 = load('LFepi9F.mat');
DynG9 = double(hst9.st_dataset);

set(0,'DefaultAxesFontName', 'Times New Roman');
set(0,'DefaultTextFontname', 'Times New Roman');
grid on;
axis equal;
axis tight;
v=[5,3,0,-3,-5,-7, -10,-15];
AgeM = (16:1:55);
AgeF = (16:1:55);
subplot(3,1,1), [c,h] = contour(AgeF,AgeM,DynG7(1:40,1:40),v);
xlabel('Age of Female');
ylabel('Age of Males');
title('a) Contour of Dynamic Gains 71/72','FontSize',13.5);
clabel(c,h,'FontSize',12,'Color','k','Rotation',0,'LabelSpacing',114);

subplot(3,1,2), [c,h] = contour(AgeF,AgeM,DynG8(1:40,1:40),v);
xlabel('Age of Female');
ylabel('Age of Males');
title('b) Contour of Dynamic Gains 81/82','FontSize',13.5);
clabel(c,h,'FontSize',12,'Color','k','Rotation',0,'LabelSpacing',114);


subplot(3,1,3), [c,h] = contour(AgeF,AgeM,DynG9(1:40,1:40),v);
xlabel('Age of Female');
ylabel('Age of Males');
title('c) Contour of Dynamic Gains 91/92','FontSize',13.5);
clabel(c,h,'FontSize',12,'Color','k','Rotation',0,'LabelSpacing',114);


